﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;

namespace UnitTestChildGameProject
{
    #region Child Game Definition
    //Static Class to calculate the Winner of the Game giving First Child ID
    public static class childGame
    {
        //Default Value of First Child ID in case not defined by user.
        public static int firstChildId = 1;

        ///Summary
        ///This Function take Below Parameter
        ///childNum : Non Zero Positive number value 
        ///outCounter : The NUmber to decide which child which will be out
        ///childOutSeq : Array contains the ID of children in order they are out from game. 
        ///              It is defined as out param so will be initlized only when valid data is passed as input.
        ///Return Value : -1 In case of Failure
        ///             : Winning Child ID
        ///Summary
        public static object getWinningChild(int childNum, int outCounter, out object[] childOutSeq)
        {

            if (childNum < 1)
            {
                Console.WriteLine("Invalid Value for Number of Children.Please Pass a non Zero positive interger.");
                childOutSeq = null;
                return -1;
            }

            if (firstChildId < 1)
            {
                Console.WriteLine("Invalid Value for First Child ID Value. Please Pass a non Zero positive interger.");
                childOutSeq = null;
                return -1;
            }

            if (outCounter < 1)
            {
                Console.WriteLine("Invalid Value for Number of Child Out Value. Please Pass a non Zero  positive interger.");
                childOutSeq = null;
                return -1;
            }

            childOutSeq = new object[childNum - 1];
            CircularLinkedList child = new CircularLinkedList();

            //Adding Children Ids to Circular Linked List
            for (int i = 0; i < childNum; i++)
                child.AddLast(firstChildId++);

            int iSeq = 0;
            //Running till one last child is left
            //Time Complexity for toal is O(childNum-1)
            while (childNum > 1)
            {
                int index = outCounter - 1;
                if (index >= childNum)
                    index = index % childNum;

                //Time Complexity for removing is O(1)- Since its Doubly Linked Circular List 
                Node removechild = child.RemoveAt(index);//Removing Node at a particlar index and set Next Element as Head

                if (removechild == null)
                {
                    return -1;
                }
                childOutSeq[iSeq++] = removechild.Value;
                removechild.Dispose();
                childNum--;
            }
            return child.Head.Value;
        }
    }
    #endregion

    #region Circular linked list Definition
    //Class to Save the Child Details
    //Circular linked list is used to reduce order complexity
    public class CircularLinkedList
    {
        Node head = null;
        Node tail = null;
        int count = 0;

        /// <summary>
        /// Gets Tail node. Returns NULL if no tail node found
        /// </summary>
        public Node Tail { get { return tail; } }

        /// <summary>
        /// Gets the head node. Returns NULL if no node found
        /// </summary>
        public Node Head { get { return head; } }

        /// <summary>
        /// Gets total number of items in the list
        /// </summary>
        public int Count { get { return count; } }

        /// <summary>
        /// Add a new item to the end of the list
        /// </summary>
        /// <param name="item">Item to be added</param>
        public void AddLast(object item)
        {
            // if head is null, then this will be the first item
            if (head == null)
                this.AddFirstItem(item);
            else
            {
                Node newNode = new Node(item);
                tail.Next = newNode;
                newNode.Next = head;
                newNode.Previous = tail;
                tail = newNode;
                head.Previous = tail;
            }
            ++count;
        }

        //Add First Item to Circular Linked List
        void AddFirstItem(object item)
        {
            head = new Node(item);
            tail = head;
            head.Next = tail;
            head.Previous = tail;
        }

        //Removing Node at a particlar index and set Next Element as Head
        public Node RemoveAt(int index)
        {
            Node currentNode = this.head;
            for (int i = 0; i <= index && currentNode != null; i++)
            {
                if (i != index)
                {
                    currentNode = currentNode.Next;
                    continue;
                }

                this.RemoveNode(currentNode);

                //Setting the Head to next Element now
                this.head = currentNode.Next;

                return currentNode;
            }

            return null;
        }

        //Removing Node from Linked List
        private void RemoveNode(Node nodeToRemove)
        {
            Node previous = nodeToRemove.Previous;
            previous.Next = nodeToRemove.Next;
            nodeToRemove.Next.Previous = nodeToRemove.Previous;

            // if this is head, we need to update the head reference
            if (head == nodeToRemove)
                head = nodeToRemove.Next;
            else if (tail == nodeToRemove)
                tail = tail.Previous;

            --count;
        }

    }
    #endregion


    #region Node Definition
    //Type to Define and Store Child Data in Circular Linked List
    public class Node : IDisposable
    {
        /// <summary>
        /// Gets the Value
        /// </summary>
        public object Value { get; private set; }

        /// <summary>
        /// Gets next node
        /// </summary>
        public Node Next { get; internal set; }

        /// <summary>
        /// Gets previous node
        /// </summary>
        public Node Previous { get; internal set; }

        /// <summary>
        /// Initializes a new <see cref="Node"/> instance
        /// </summary>
        /// <param name="item">Value to be assigned</param>
        internal Node(object item)
        {
            this.Value = item;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (!disposing)
            {
                return;
            }
            if (Value == null)
            {
                return;
            }
            System.IDisposable disposableObject = Value as System.IDisposable;
            Value = null;

            if (disposableObject != null)
            {
                disposableObject.Dispose();
            }
        }
    }
    #endregion

    #region Unit Test cases    
    [TestClass]
    public class ChildGameTest
    {
        [TestMethod]
        //Positive Test - Method when Number of Kids is Greater than the Out Counter (n>k)
        public void TestMethod1()
        {
            //Total Number of Children
            int n = 7;

            //Counter To decide who leaves the circle
            int k = 5;

            childGame.firstChildId = 1;

            object winChild = childGame.getWinningChild(n, k, out object[] childOutSeq);

            object[] expectedOutSeq = new object[] { 5, 3, 2, 4, 7, 1 };

            //Checking Out Sequence is as Expected
            Assert.AreEqual(true, Enumerable.SequenceEqual(expectedOutSeq, childOutSeq));

            //Checking Winning Child
            Assert.AreEqual(6, winChild);
        }
        [TestMethod]
        //Positive Test - Method when Number of Kids is less than the Out Counter(n < k)
        public void TestMethod2()
        {
            //Total Number of Children
            int n = 7;

            //Counter To decide who leaves the circle
            int k = 10;

            childGame.firstChildId = 21;

            object winChild = childGame.getWinningChild(n, k, out object[] childOutSeq);

            object[] expectedOutSeq = new object[] { 23, 27, 26, 22, 24, 21 };

            //Checking Out Sequence is as Expected
            Assert.AreEqual(true, Enumerable.SequenceEqual(expectedOutSeq, childOutSeq));

            //Checking Winning Child
            Assert.AreEqual(25, winChild);
        }

        [TestMethod]
        //Negative Test - Method when Number of Kids "n" Value given by user is negative
        public void TestMethod3()
        {
            //Total Number of Children
            int n = -10;

            //Counter To decide who leaves the circle
            int k = 10;

            childGame.firstChildId = 21;

            object winChild = childGame.getWinningChild(n, k, out object[] childOutSeq);

            //Checking there should be no Winning Child 
            Assert.AreEqual(-1, winChild);

            //Checking Out Sequence is as Expected
            Assert.AreEqual(null, childOutSeq);


        }

        [TestMethod]
        //Negative Test - Method when Out Count Value "k" given by user is negative
        public void TestMethod4()
        {
            //Total Number of Children
            int n = 7;

            //Counter To decide who leaves the circle
            int k = -1;

            childGame.firstChildId = 21;

            object winChild = childGame.getWinningChild(n, k, out object[] childOutSeq);

            //Checking there should be no Winning Child 
            Assert.AreEqual(-1, winChild);

            //Checking Out Sequence is as Expected
            Assert.AreEqual(null, childOutSeq);


        }
        [TestMethod]
        //Negative Test - Method when firstChildId given by user is negative
        public void TestMethod5()
        {
            //Total Number of Children
            int n = 7;

            //Counter To decide who leaves the circle
            int k = 10;

            childGame.firstChildId = -1;

            object winChild = childGame.getWinningChild(n, k, out object[] childOutSeq);

            //Checking there should be no Winning Child 
            Assert.AreEqual(-1, winChild);

            //Checking Out Sequence is as Expected
            Assert.AreEqual(null, childOutSeq);
        }

        [TestMethod]
        //Boundry Test - Run Method when firstChildId given by user is negative
        public void TestMethod6()
        {
            //Total Number of Children
            int n = 7;

            //Counter To decide who leaves the circle
            int k = 1;

            childGame.firstChildId = 1;

            object winChild = childGame.getWinningChild(n, k, out object[] childOutSeq);

            object[] expectedOutSeq = new object[] { 1, 2, 3, 4, 5, 6 };

            //Checking Out Sequence is as Expected
            Assert.AreEqual(true, Enumerable.SequenceEqual(expectedOutSeq, childOutSeq));

            //Checking Winning Child
            Assert.AreEqual(7, winChild);
        }
    }
    #endregion
}
